class Time
{
    public:
        Time(int, int, int, int);
        int convertionToSec();
        void convertionToTime(double);
        void multiply(double);
        void divide(double);
        void show();
        int get_a();
    private:
        int a, b, c, d;
};
