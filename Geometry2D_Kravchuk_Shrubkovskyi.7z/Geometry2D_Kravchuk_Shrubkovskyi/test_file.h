void test_file();
void test_cross_section1();
void test_cross_line1();
void test_inserction_of_line_and_section1();
void test_triangle1();
