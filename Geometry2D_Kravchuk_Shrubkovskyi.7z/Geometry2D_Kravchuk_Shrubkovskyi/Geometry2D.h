struct Point2D
{
    double x;
    double y;
};

struct Segment2D
{
    Point2D point1;
    Point2D point2;
};

struct Triangle2D
{
    Point2D A;
    Point2D B;
    Point2D C;
};

struct Line2D
{
    double a, b, c;
};

double leght(Point2D A, Point2D B);

double perimetr(Triangle2D ABC);

Point2D insersect(Segment2D a, Segment2D b);

Point2D insersect(Line2D AB, Line2D CD);

double area(Triangle2D ABC);

Line2D equation_of_height(Point2D A, Segment2D BC);

Line2D bisector_equation(Point2D A, Segment2D AB, Segment2D AC);

Line2D perpendicular(Segment2D AB);

Point2D center_of_the_described_circle(Triangle2D ABC);

double radius_of_the_circle_describe(Triangle2D ABC);

void center(Triangle2D ABC);

Point2D center_of_the_insetred_circle(Triangle2D ABC);

double radius_of_the_circle_entered(Triangle2D ABC);

Line2D mediana(Point2D A, Segment2D BC);

Line2D angle_triangle(Triangle2D ABC);

Point2D insersect(Line2D m, Segment2D AB);

double area_figure(Line2D a, Triangle2D ABC);
