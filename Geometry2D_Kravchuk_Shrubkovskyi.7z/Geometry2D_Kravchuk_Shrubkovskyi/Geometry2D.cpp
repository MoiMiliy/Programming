#include <iostream>
#include <cmath>
#include <windows.h>
#include "Geometry2D.h"
#define PI 3.14159265
using namespace std;

double leght(Point2D A, Point2D B)
{
    return sqrt((A.x-B.x)*(A.x-B.x)+(A.y-B.y)*(A.y-B.y));
}

double perimetr(Triangle2D ABC)
{
    double AB = leght(ABC.A, ABC.B);
    double AC = leght(ABC.A, ABC.C);
    double CB = leght(ABC.C, ABC.B);
    double P = (AB+AC+CB);
    return P;
}

Point2D insersect(Segment2D AB, Segment2D CD)
{
    Line2D n, m;
    n.a = AB.point2.y-AB.point1.y, n.b = -(AB.point2.x-AB.point1.x);
    n.c = -n.a*AB.point1.x-n.b*AB.point1.y;
    m.a = CD.point2.y-CD.point1.y, m.b = -(CD.point2.x-CD.point1.x);
    m.c = -m.a*CD.point1.x-m.b*CD.point1.y;
    Point2D X1, X2;
    X1 = insersect(m, n);
    X2.x = INFINITE;
    X2.y = INFINITE;
    if(X1.x<=AB.point1.x && X1.x>=AB.point2.x)
    {
        return X1;
    }
    else if(X1.x>=AB.point1.x && X1.x<=AB.point2.x)
    {
        return X1;
    }
    else
        return X2;
}

Point2D insersect(Line2D AB, Line2D CD)
{
    Point2D N;
    if(AB.a/CD.a != AB.b/CD.b)
    {
        N.x = (AB.b*CD.c-CD.b*AB.c)/(AB.a*CD.b-CD.a*AB.b);
        N.y = (AB.c*CD.a-CD.c*AB.a)/(AB.a*CD.b-CD.a*AB.b);
    }
    else
    {
        N.x = INFINITE;
        N.y = INFINITE;
    }
    return N;
}

double area(Triangle2D ABC)
{
    double AB = leght(ABC.A, ABC.B);
    double AC = leght(ABC.A, ABC.C);
    double CB = leght(ABC.C, ABC.B);
    double p = perimetr(ABC)/2;
    double S = sqrt(p*(p-AB)*(p-AC)*(p-CB));
    return S;
}

Line2D equation_of_height(Point2D A, Segment2D BC)
{
    Line2D hight;
    if(BC.point1.y == BC.point2.y)
    {
        hight.a = 1, hight.b = 0, hight.c = -A.x;
    }
    else
    {
        double k1 = (BC.point2.y-BC.point1.y)/(BC.point2.x-BC.point1.x);
        double k2 = -1/k1;
        double c = -A.y+k2*A.x;
        hight.a = -k2, hight.b = 1, hight.c = c;
    }

    return hight;
}

Line2D bisector_equation(Point2D A, Segment2D AB, Segment2D AC)
{
    double len_AB = leght(AB.point1, AB.point2);
    double len_AC = leght(AC.point1, AC.point2);
    double a = (AB.point2.x-AB.point1.x), b = (AB.point2.y-AB.point1.y);
    double c = (AC.point2.x-AC.point1.x), d = (AC.point2.y-AC.point1.y);
    double coef_A = len_AC*a-len_AB*c;
    double coef_B = len_AC*b-len_AB*d;
    double coef_C = -(coef_A*A.x+coef_B*A.y);
    Line2D bisector;
    bisector.a = coef_A/coef_B, bisector.b = 1, bisector.c = coef_C/coef_B;

    return bisector;
}

Line2D perpendicular(Segment2D AB)
{
    Point2D H;
    H.x = (AB.point1.x+AB.point2.x)/2;
    H.y = (AB.point1.y+AB.point2.y)/2;
    Line2D m;
    double k;
    if(AB.point1.x == AB.point2.x)
    {
        m.a = 0, m.b = 1, m.c = -H.y;
        return m;
    }
    else if(AB.point1.y == AB.point2.y)
    {
        m.a = 1, m.b = 0, m.c = -H.x;
        return m;
    }
    else
        k = -(AB.point2.x-AB.point1.x)/(AB.point2.y-AB.point1.y);
    double b = -H.y+k*H.x;
    m.a = -k, m.b = 1, m.c = b;
    return m;
}

Point2D center_of_the_described_circle(Triangle2D ABC)
{
    Segment2D AB, AC;
    AC.point1 = ABC.A, AC.point2 = ABC.C;
    AB.point1 = ABC.A, AB.point2 = ABC.B;
    Line2D a, b;
    a = perpendicular(AB);
    b = perpendicular(AC);
    Point2D X = insersect(a, b);
    return X;
}

double radius_of_the_circle_describe(Triangle2D ABC)
{
    double S = area(ABC);
    double a = leght(ABC.A, ABC.B);
    double b = leght(ABC.C, ABC.B);
    double c = leght(ABC.A, ABC.C);
    double R = (a*b*c)/(4*S);
    return R;
}

Point2D center_of_the_insetred_circle(Triangle2D ABC)
{
    Line2D a, b;
    Segment2D AB, AC;
    AC.point1 = ABC.A, AC.point2 = ABC.C;
    AB.point1 = ABC.A, AB.point2 = ABC.B;
    a = bisector_equation(ABC.A, AB, AC);
    Segment2D BA, BC;
    BA.point1 = ABC.B, BA.point2 = ABC.A;
    BC.point1 = ABC.B, BC.point2 = ABC.C;
    b = bisector_equation(ABC.B, BA, BC);
    Point2D X;
    X = insersect(a, b);
    return X;
}

double radius_of_the_circle_entered(Triangle2D ABC)
{
    double S = area(ABC);
    double p = perimetr(ABC)/2;
    double r = S/p;
    return r;
}

void center(Triangle2D ABC)
{
    Point2D N;
    N.x = (ABC.A.x+ABC.B.x+ABC.C.x)/3;
    N.y = (ABC.A.y+ABC.B.y+ABC.C.y)/3;
    cout << "���������� ������ ��� ���������� N(" << N.x << ", " << N.y << ")" << endl;
}


Line2D angle_triangle(Triangle2D ABC)
{
    Line2D angle;
    double a = leght(ABC.C, ABC.B);
    double b = leght(ABC.C, ABC.A);
    double c = leght(ABC.A, ABC.B);
    angle.a = acos((b*b+c*c-a*a)/(2*b*c))*180/PI;
    angle.b = acos((a*a+c*c-b*b)/(2*a*c))*180/PI;
    angle.c = 180-(angle.a+angle.b);
    return angle;
}

Line2D mediana(Point2D A, Segment2D BC)
{
    Point2D K;
    K.x = (BC.point1.x+BC.point2.x)/2;
    K.y = (BC.point1.y+BC.point2.y)/2;
    double a = K.y-A.y, b = K.x-A.x;
    double c = A.y*b-A.x*a;
    Line2D med;
    med.a = a, med.b = -b, med.c = c;

    return med;
}


Point2D insersect(Line2D m, Segment2D AB)
{
    Line2D n;
    n.a = AB.point2.y-AB.point1.y, n.b = -(AB.point2.x-AB.point1.x);
    n.c = -n.a*AB.point1.x-n.b*AB.point1.y;
    Point2D X1, X2;
    X1 = insersect(m, n);
    X2.x = INFINITE;
    X2.y = INFINITE;
    if(X1.x<=AB.point1.x && X1.x>=AB.point2.x)
    {
        return X1;
    }
    else if(X1.x>=AB.point1.x && X1.x<=AB.point2.x)
    {
        return X1;
    }
    else
        return X2;
}

double area_figure(Line2D a, Triangle2D ABC)
{
    Point2D X1, X2, X3;
    Segment2D AB, BC, AC;
    AB.point1 = ABC.A, AB.point2 = ABC.B;
    BC.point1 = ABC.B, BC.point2 = ABC.C;
    AC.point1 = ABC.A, AC.point2 = ABC.C;
    X1 = insersect(a, AB);
    X2 = insersect(a, BC);
    X3 = insersect(a, AC);
    bool len1 = false;
    bool len2 = false;
    bool len3 = false;
    if(leght(ABC.A, X1) < INFINITE)
        len1 = true;
    if(leght(ABC.B, X2) < INFINITE)
        len2 = true;
    if(leght(ABC.A, X3) < INFINITE)
        len3 = true;
    double S;
    if(len1 && len2)
    {
        Triangle2D cut;
        cut.A = X1, cut.B = ABC.B, cut.C = X2;
        S = area(cut);
        return S;
    }
    else if(len2 && len3)
    {
        Triangle2D cut;
        S = area(cut);
        return S;
    }
    else if(len1 && len3)
    {
        Triangle2D cut;
        cut.A = ABC.A, cut.B = X1, cut.C = X3;
        S = area(cut);
        return S;
    }
    else
       return 0;
}
