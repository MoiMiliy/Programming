void test_consol();
void test_cross_section();
void test_cross_line();
void test_inserction_of_line_and_section();
void test_triangle();
